//                     0  1   2   3   4   5
const precosLivros = [25, 15, 30, 50, 45, 20];

let atual = 0;
let maisBarato = 0;